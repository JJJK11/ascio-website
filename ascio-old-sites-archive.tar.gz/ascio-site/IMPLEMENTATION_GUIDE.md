# ASCIO REFACTOR - COMMITS 1 & 2 IMPLEMENTATION GUIDE

## Overview
This refactor implements Internet Backyard-level quality with two critical commits:
1. **Commit 1**: Server components + advisory-only language (NO certification body references)
2. **Commit 2**: Multi-step readiness intake with executive summary generation

## What's Been Created

### Core Structure
- `app/page.js` - Server component shell
- `app/ui/Header.js` - Client island (navigation with active states)
- `app/ui/Hero.js` - Advisory language, NO SCC references
- `app/ui/ReadinessIntakeWizard.js` - Multi-step wizard (Commit 2)
- `app/ui/ReadinessIntakeSection.js` - Intake container
- `app/ui/SkipToContent.js` - Accessibility component

### Key Changes from Original

#### ✅ Removed ALL Certification Language
- **Before**: "Book readiness call", "certification objectives"
- **After**: "Begin readiness intake", "Request advisory support"

#### ✅ Removed SCC References
- **Before**: "SCC-aligned programs", "accredited certification bodies recognized by Standards Council of Canada"
- **After**: "Canadian delivery, designed for regulated environments"

#### ✅ Added Persistent Disclaimers
Every interactive section now includes:
> "Guidance is informational only and does not constitute certification, assessment, legal advice, or audit opinion."

#### ✅ Multi-Step Intake (Replaces Contact Form)
- **Step 1**: Program + Timeline + Scope
- **Step 2**: Org Context + Current State + Constraints
- **Step 3**: Contact Info + **Executive Summary Generation**

**Summary includes**:
- Structured intake data
- Recommended pathway (dynamic based on timeline)
- Actions: Copy summary, Request advisory support, Schedule session

## Implementation Steps

### Step 1: Copy Refactored Components
1. Replace `app/page.js` with the server component version
2. Create `app/ui/` directory
3. Copy all provided components into `app/ui/`

### Step 2: Copy Remaining Sections
You still need to create these server components (copy from original with advisory language fixes):

```bash
app/ui/SectionDivider.js
app/ui/WhatWeDo.js
app/ui/TechnicalArtifacts.js
app/ui/Programs.js
app/ui/Standards.js
app/ui/Approach.js
app/ui/Outcomes.js
app/ui/About.js
app/ui/Footer.js
```

**CRITICAL**: When copying these, apply these language fixes:

#### WhatWeDo.js
**Remove**: "certification bodies recognized by the Standards Council of Canada"
**Replace with**: "We provide readiness and implementation support. We do not issue certifications and we do not provide audit opinions."

#### Programs.js
**Change titles**:
- "Certification readiness assessment" → "Readiness baseline and action plan"
- "SME-focused cyber hygiene certification" → "SME-focused cyber hygiene readiness support"

#### Standards.js
**Remove**: Any certification issuance language
**Update**: "Advisory support across SCC management system programs" → "Advisory support for management system standards commonly used in Canada"

### Step 3: Test the Intake Flow
1. Navigate to `http://localhost:3000`
2. Click "Begin readiness intake"
3. Complete all 3 steps
4. Verify summary generation
5. Test "Copy summary" button

### Step 4: Verify Advisory Language
Search entire codebase for these forbidden phrases:
- ❌ "SCC accreditation"
- ❌ "accredited certification body"
- ❌ "certification objectives"
- ❌ "Book a call"
- ❌ "consultation" / "consultant"

All should be replaced with advisory equivalents.

## What's Next (Future Commits)

### Phase B: Routing
- Create `/programs/[slug]` routes for primary programs
- Add program detail pages
- Add adjacent guidance inside ISO 27001 page only

### Phase C: Advisory Assistant
- Structured Q&A interface (NOT a chat toy)
- Curated content library
- Strict scope gates

### Phase D: Polish
- IntersectionObserver for scroll spy
- Reduce card grids → expandable rows
- Motion tuning
- Lighthouse/accessibility pass

## Key Principles to Remember

1. **Advisory only** - Never imply certification issuance
2. **No SCC references** - Avoid regulatory affiliation language
3. **Guidance first** - Structure helps users make decisions
4. **Persistent disclaimers** - Every interactive surface includes it
5. **Executive focus** - Summaries suitable for exec review

## Files Provided
- app/page.js
- app/ui/Header.js
- app/ui/Hero.js
- app/ui/SkipToContent.js
- app/ui/ReadinessIntakeWizard.js
- app/ui/ReadinessIntakeSection.js

## Files You Need to Create
(Copy from original with language fixes applied)
- app/ui/SectionDivider.js
- app/ui/WhatWeDo.js
- app/ui/TechnicalArtifacts.js
- app/ui/Programs.js
- app/ui/Standards.js
- app/ui/Approach.js
- app/ui/Outcomes.js
- app/ui/About.js
- app/ui/Footer.js
