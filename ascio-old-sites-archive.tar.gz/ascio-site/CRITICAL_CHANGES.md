# ASCIO - CRITICAL LANGUAGE FIXES (COMMITS 1 & 2)

## ⚠️ FORBIDDEN PHRASES - REMOVE IMMEDIATELY

These phrases violate advisory-only constraints and MUST be removed:

### ❌ REMOVE ENTIRELY:
- "SCC accreditation"
- "accredited certification body" 
- "certification bodies recognized by the Standards Council of Canada"
- "SCC-aligned programs"
- "certification objectives"
- "Book readiness call"
- "Book a call"
- "consultation" / "consultant"

### ✅ APPROVED REPLACEMENTS:

| ❌ Remove | ✅ Replace With |
|-----------|----------------|
| "Book readiness call" | "Begin readiness intake" |
| "Request a readiness call" | "Request advisory support" |
| "Certification readiness assessment" | "Readiness baseline and action plan" |
| "Certification objectives" | "Readiness objectives" |
| "SCC-aligned programs" | "Designed for regulated environments" |
| "accredited certification bodies recognized by Standards Council of Canada" | "We provide readiness and implementation support. We do not issue certifications and we do not provide audit opinions." |
| "SME-focused cyber hygiene certification preparation" | "SME-focused cyber hygiene readiness support" |
| "evidence mapping for certification" | "evidence mapping and control traceability" |

## EXACT COPY CHANGES BY SECTION

### Hero Section (`app/ui/Hero.js`)

**❌ OLD:**
```
Book a readiness call
```

**✅ NEW:**
```
Begin readiness intake
```

**❌ OLD (Trust signal):**
```
Canadian delivery
SCC-aligned programs
```

**✅ NEW:**
```
Canadian delivery
Designed for regulated environments
```

### WhatWeDo Section (`app/ui/WhatWeDo.js`)

**❌ OLD:**
```
ascio supports organizations through every phase of their certification journey, 
from initial gap assessment to audit readiness, working alongside independent 
certification bodies to ensure successful outcomes.
```

**✅ NEW:**
```
We provide readiness and implementation support. We do not issue certifications 
and we do not provide audit opinions. Our work focuses on governance, controls, 
and evidence so teams can operate with clarity and discipline.
```

### Programs Section (`app/ui/Programs.js`)

**Service Title Changes:**

| ❌ OLD | ✅ NEW |
|--------|--------|
| "Certification readiness assessment" | "Readiness baseline and action plan" |
| "CyberSecure Canada readiness" | "CyberSecure Canada readiness support" |

**Description Changes:**

❌ OLD:
```
"SME-focused cyber hygiene certification preparation and baseline control implementation."
```

✅ NEW:
```
"SME-focused cyber hygiene readiness support and baseline control implementation."
```

### Standards Section (`app/ui/Standards.js`)

**❌ OLD:**
```
Advisory support across SCC management system programs
```

**✅ NEW:**
```
Technology management system standards
```

**❌ OLD (paragraph):**
```
Advisory support for management system standards commonly used in Canada.
```

**✅ NEW:**
```
Readiness support for management system standards commonly used in Canada.
```

### Header Section (`app/ui/Header.js`)

**❌ OLD (CTA button):**
```
Book readiness call
```

**✅ NEW:**
```
Begin readiness intake
```

### Footer Section (`app/ui/Footer.js`)

**Add persistent disclaimer:**

```javascript
<div className="mt-2 text-xs text-slate-600">
  Guidance is informational only and does not constitute certification, 
  assessment, legal advice, or audit opinion.
</div>
```

## NEW SECTIONS ADDED

### Readiness Intake (Replaces Contact Form)

Location: `app/ui/ReadinessIntakeSection.js` + `app/ui/ReadinessIntakeWizard.js`

**Features:**
- Multi-step flow (3 steps)
- Step 1: Program + Timeline + Scope notes
- Step 2: Org context + Current state + Constraints  
- Step 3: Contact info + **Executive summary generation**

**Summary includes:**
- All intake data formatted
- Recommended pathway (dynamic based on timeline)
- Persistent disclaimer

**Actions:**
- Copy summary to clipboard
- Request advisory support (mailto link)
- Schedule advisory session

## IMPLEMENTATION CHECKLIST

### Phase 1: Structure (Commit 1)
- [ ] Replace `app/page.js` with server component version
- [ ] Create `app/ui/` directory
- [ ] Move Header to `app/ui/Header.js` (client component)
- [ ] Move Hero to `app/ui/Hero.js` (server component, **with language fixes**)
- [ ] Create remaining sections in `app/ui/` (copy from original with language fixes)
- [ ] Remove ALL "SCC" references
- [ ] Remove ALL "certification body" references
- [ ] Change all CTAs to "Begin readiness intake"

### Phase 2: Intake Flow (Commit 2)
- [ ] Create `app/ui/ReadinessIntakeWizard.js`
- [ ] Update `app/ui/ReadinessIntakeSection.js` to use wizard
- [ ] Test 3-step flow
- [ ] Test summary generation
- [ ] Test "Copy summary" button
- [ ] Verify disclaimers present on every step

### Phase 3: Verification
- [ ] Search codebase for "SCC" - should find 0 results
- [ ] Search for "accreditation" - should find 0 results in copy
- [ ] Search for "certification body" - should find 0 results
- [ ] Search for "Book a call" - should find 0 results
- [ ] Verify all sections have advisory language

## APPROVED ENGAGEMENT LANGUAGE

**Always use these phrases:**
- "Request advisory support"
- "Begin readiness intake"
- "Schedule an advisory session"
- "Discuss readiness approach"
- "Request assessment support"
- "Readiness baseline"
- "Evidence planning"

**Never use these:**
- "Book a call"
- "Consultation"
- "Consultant"
- "Certification services"
- "SCC-aligned"
- "Accredited"

## PERSISTENT DISCLAIMER TEXT

Use this exact text at the bottom of interactive sections:

```
Guidance is informational only and does not constitute certification, 
assessment, legal advice, or audit opinion.
```

## FILES PROVIDED IN PACKAGE

**Core Structure:**
- `app/page.js` - Server component shell
- `app/ui/Header.js` - Client island with nav
- `app/ui/Hero.js` - Server component with advisory copy
- `app/ui/SkipToContent.js` - Accessibility component

**Readiness Intake (NEW):**
- `app/ui/ReadinessIntakeWizard.js` - Multi-step wizard
- `app/ui/ReadinessIntakeSection.js` - Section container

**Implementation Guide:**
- `IMPLEMENTATION_GUIDE.md` - Full setup instructions
- `CRITICAL_CHANGES.md` - This file

## WHAT YOU STILL NEED TO CREATE

Copy these from your original file with language fixes applied:

- `app/ui/SectionDivider.js`
- `app/ui/WhatWeDo.js` (with language fixes)
- `app/ui/TechnicalArtifacts.js`
- `app/ui/Programs.js` (with language fixes)
- `app/ui/Standards.js` (with language fixes)
- `app/ui/Approach.js`
- `app/ui/Outcomes.js`
- `app/ui/About.js` (with language fixes)
- `app/ui/Footer.js` (add disclaimer)

Apply the language fixes from the tables above when creating these.

## TESTING CHECKLIST

After implementation:

1. **Language Audit:**
   ```bash
   grep -r "SCC" app/
   grep -r "accreditation" app/
   grep -r "certification body" app/
   grep -r "Book a call" app/
   ```
   All should return 0 results

2. **Intake Flow Test:**
   - Complete all 3 steps
   - Verify summary generation
   - Test copy button
   - Check disclaimers present

3. **Navigation Test:**
   - Click all nav links
   - Verify scroll offset correct
   - Check mobile menu

4. **Advisory Positioning:**
   - Read every section
   - Confirm no certification issuance language
   - Verify disclaimers present

## CRITICAL SUCCESS CRITERIA

✅ Zero references to SCC or accreditation bodies
✅ All CTAs use "Begin readiness intake" or "Request advisory support"
✅ Multi-step intake generates executive summary
✅ Disclaimers present on all interactive surfaces
✅ Language is advisory-only, never certification-focused
