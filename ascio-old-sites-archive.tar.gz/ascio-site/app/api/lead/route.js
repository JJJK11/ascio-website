export async function POST(request) {
  try {
    const data = await request.json();

    // Validate required fields
    if (!data.name || !data.email || !data.company) {
      return Response.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      return Response.json(
        { error: 'Invalid email address' },
        { status: 400 }
      );
    }

    // TODO: Integrate with your CRM or email service
    // Examples:
    // - Send to HubSpot, Salesforce, etc.
    // - Send email via SendGrid, Resend, etc.
    // - Store in database

    console.log('Lead submission received:', {
      name: data.name,
      email: data.email,
      company: data.company,
      standard: data.standard,
      timeline: data.timeline,
      notes: data.notes,
      timestamp: new Date().toISOString(),
    });

    return Response.json({ success: true });
  } catch (error) {
    console.error('Lead submission error:', error);
    return Response.json(
      { error: 'Failed to process submission' },
      { status: 500 }
    );
  }
}
