// app/page.js

import Header from "./ui/Header";
import Hero from "./ui/Hero";
import SectionDivider from "./ui/SectionDivider";
import WhatWeDo from "./ui/WhatWeDo";
import TechnicalArtifacts from "./ui/TechnicalArtifacts";
import Programs from "./ui/Programs";
import Standards from "./ui/Standards";
import Approach from "./ui/Approach";
import Outcomes from "./ui/Outcomes";
import About from "./ui/About";
import ReadinessIntakeSection from "./ui/ReadinessIntakeSection";
import Footer from "./ui/Footer";
import SkipToContent from "./ui/SkipToContent";

export default function Page() {
  return (
    <main className="min-h-screen bg-slate-950 text-white">
      <SkipToContent />
      <Header />
      <Hero />
      <SectionDivider />
      <WhatWeDo />
      <TechnicalArtifacts />
      <Programs />
      <Standards />
      <Approach />
      <Outcomes />
      <About />
      <ReadinessIntakeSection />
      <Footer />
    </main>
  );
}