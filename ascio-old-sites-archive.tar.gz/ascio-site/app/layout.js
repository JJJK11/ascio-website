import { Instrument_Serif, Work_Sans } from "next/font/google";
import "./globals.css";

const instrumentSerif = Instrument_Serif({
  weight: ['400'],
  style: ['normal', 'italic'],
  subsets: ['latin'],
  variable: '--font-serif',
});

const workSans = Work_Sans({
  weight: ['300', '400', '500', '600', '700'],
  subsets: ['latin'],
  variable: '--font-sans',
});

export const metadata = {
  title: "ascio | Certification Readiness & Standards-Led Delivery",
  description: "We help organizations achieve ISO certification on the first audit through structured readiness programs, evidence-based gap analysis, and audit-ready documentation.",
  icons: {
    icon: '/ascio_Favicon.png',
    apple: '/ascio_Favicon.png',
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body
        className={`${instrumentSerif.variable} ${workSans.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
