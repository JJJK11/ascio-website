// app/ui/TechnicalArtifacts.js

export default function TechnicalArtifacts() {
  return (
    <section className="bg-slate-900 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mb-16">
          <div className="mb-4 text-xs font-medium tracking-widest text-[#6FA3C8] uppercase">
            Technical Deliverables
          </div>
          <h2 className="text-3xl font-bold tracking-tight text-white md:text-4xl">
            Technology management system artifacts
          </h2>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <div className="bg-gradient-to-b from-white/4 to-transparent p-8 rounded-xl">
            <h3 className="text-lg font-semibold text-white mb-4">Evidence architecture</h3>
            <ul className="space-y-3 text-sm text-slate-400">
              <li className="flex items-start gap-3">
                <div className="mt-1.5 h-1 w-1 rounded-full bg-[#6FA3C8] flex-shrink-0" />
                Evidence matrix and control mapping
              </li>
              <li className="flex items-start gap-3">
                <div className="mt-1.5 h-1 w-1 rounded-full bg-[#6FA3C8] flex-shrink-0" />
                Statement of Applicability (ISO 27001)
              </li>
              <li className="flex items-start gap-3">
                <div className="mt-1.5 h-1 w-1 rounded-full bg-[#6FA3C8] flex-shrink-0" />
                Risk register and treatment plan
              </li>
            </ul>
          </div>

          <div className="bg-gradient-to-b from-white/4 to-transparent p-8 rounded-xl">
            <h3 className="text-lg font-semibold text-white mb-4">Audit readiness</h3>
            <ul className="space-y-3 text-sm text-slate-400">
              <li className="flex items-start gap-3">
                <div className="mt-1.5 h-1 w-1 rounded-full bg-[#6FA3C8] flex-shrink-0" />
                Internal audit toolkit and checklists
              </li>
              <li className="flex items-start gap-3">
                <div className="mt-1.5 h-1 w-1 rounded-full bg-[#6FA3C8] flex-shrink-0" />
                Corrective action tracker
              </li>
              <li className="flex items-start gap-3">
                <div className="mt-1.5 h-1 w-1 rounded-full bg-[#6FA3C8] flex-shrink-0" />
                Readiness dashboard and scoring
              </li>
            </ul>
          </div>

          <div className="bg-gradient-to-b from-white/4 to-transparent p-8 rounded-xl">
            <h3 className="text-lg font-semibold text-white mb-4">Control frameworks</h3>
            <ul className="space-y-3 text-sm text-slate-400">
              <li className="flex items-start gap-3">
                <div className="mt-1.5 h-1 w-1 rounded-full bg-[#6FA3C8] flex-shrink-0" />
                Policy and procedure templates
              </li>
              <li className="flex items-start gap-3">
                <div className="mt-1.5 h-1 w-1 rounded-full bg-[#6FA3C8] flex-shrink-0" />
                Control design and ownership mapping
              </li>
              <li className="flex items-start gap-3">
                <div className="mt-1.5 h-1 w-1 rounded-full bg-[#6FA3C8] flex-shrink-0" />
                Document hierarchy and approval workflow
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
