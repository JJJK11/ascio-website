// app/ui/ReadinessIntakeSection.js

import ReadinessIntakeWizard from "./ReadinessIntakeWizard";

export default function ReadinessIntakeSection() {
  return (
    <section id="intake" className="bg-slate-900 py-24 md:py-32 scroll-mt-20">
      <div className="mx-auto max-w-4xl px-6 lg:px-8">
        <div className="mb-10">
          <div className="mb-4 text-xs font-medium tracking-widest text-[#6FA3C8] uppercase">
            Readiness intake
          </div>
          <h2 className="mb-4 text-3xl font-bold tracking-tight text-white md:text-4xl">
            Begin readiness intake
          </h2>
          <p className="text-lg leading-relaxed text-slate-400">
            Provide structured context. Receive a readiness summary suitable for executive review.
          </p>
        </div>

        <ReadinessIntakeWizard />

        <div className="mt-10 text-sm text-slate-500">
          If you prefer to email directly, contact <a className="text-[#6FA3C8] hover:text-[#6FA3C8]/80" href="mailto:hello@ascio.ca">hello@ascio.ca</a>.
        </div>
      </div>
    </section>
  );
}
