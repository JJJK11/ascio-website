// app/ui/ReadinessIntakeWizard.js
"use client";

import { useMemo, useState } from "react";

const PROGRAMS = [
  "ISO/IEC 27001",
  "ISO/IEC 42001",
  "ISO/IEC 20000-1",
  "ISO 22301",
  "CyberSecure Canada",
  "CP-CSC (Future program)",
  "ISO 9001",
  "ISO 14001",
  "ISO 45001",
  "ISO 50001",
  "Other",
];

const TIMELINES = ["Within 3 months", "3 to 6 months", "6 to 12 months", "12 plus months", "Exploratory"];

function clampText(value, max = 1200) {
  const v = String(value || "");
  return v.length > max ? v.slice(0, max) : v;
}

export default function ReadinessIntakeWizard() {
  const [step, setStep] = useState(1);

  const [data, setData] = useState({
    program: "",
    timeline: "",
    orgType: "",
    scopeNotes: "",
    currentState: "",
    constraints: "",
    contactName: "",
    contactEmail: "",
    company: "",
    consent: false,
  });

  const canNext = useMemo(() => {
    if (step === 1) return Boolean(data.program) && Boolean(data.timeline);
    if (step === 2) return Boolean(data.orgType) && Boolean(data.currentState);
    if (step === 3) return Boolean(data.contactName) && Boolean(data.contactEmail) && Boolean(data.consent);
    return true;
  }, [step, data]);

  const summary = useMemo(() => {
    const lines = [
      { k: "Program", v: data.program || "Not specified" },
      { k: "Timeline", v: data.timeline || "Not specified" },
      { k: "Organization context", v: data.orgType || "Not specified" },
      { k: "Current state", v: data.currentState || "Not specified" },
      { k: "Scope notes", v: data.scopeNotes || "Not specified" },
      { k: "Constraints", v: data.constraints || "Not specified" },
      { k: "Company", v: data.company || "Not specified" },
      { k: "Primary contact", v: data.contactName || "Not specified" },
      { k: "Email", v: data.contactEmail || "Not specified" },
    ];

    const recommendedPathway =
      data.timeline === "Within 3 months"
        ? "Validate and focus. Evidence first. Reduce scope and prioritize control traceability."
        : data.timeline === "Exploratory"
          ? "Baseline and plan. Confirm scope, governance, and an evidence model before implementation."
          : "Build with cadence. Establish governance, implement controls, and run internal validation cycles.";

    return { lines, recommendedPathway };
  }, [data]);

  function update(patch) {
    setData(prev => ({ ...prev, ...patch }));
  }

  async function copySummary() {
    const text = [
      "Ascio readiness intake summary",
      "",
      ...summary.lines.map(x => `${x.k}: ${x.v}`),
      "",
      "Recommended pathway",
      summary.recommendedPathway,
      "",
      "Disclaimer",
      "Guidance is informational only and does not constitute certification, assessment, legal advice, or audit opinion.",
    ].join("\n");

    await navigator.clipboard.writeText(text);
  }

  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.03] p-8">
      <div className="flex items-center justify-between gap-4">
        <div className="text-sm text-slate-400">Step {step} of 3</div>
        <div className="text-xs text-slate-600">
          Guidance is informational only and does not constitute certification, assessment, legal advice, or audit opinion.
        </div>
      </div>

      {step === 1 && (
        <div className="mt-8 space-y-6">
          <div>
            <label className="text-sm font-medium text-slate-300">Program</label>
            <select
              value={data.program}
              onChange={(e) => update({ program: e.target.value })}
              className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white focus:border-[#6FA3C8]/50 focus:outline-none focus:ring-4 focus:ring-[#6FA3C8]/20"
            >
              <option value="" className="bg-slate-900">Select a program</option>
              {PROGRAMS.map(p => (
                <option key={p} className="bg-slate-900" value={p}>{p}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-sm font-medium text-slate-300">Timeline</label>
            <select
              value={data.timeline}
              onChange={(e) => update({ timeline: e.target.value })}
              className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white focus:border-[#6FA3C8]/50 focus:outline-none focus:ring-4 focus:ring-[#6FA3C8]/20"
            >
              <option value="" className="bg-slate-900">Select timeline</option>
              {TIMELINES.map(t => (
                <option key={t} className="bg-slate-900" value={t}>{t}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-sm font-medium text-slate-300">Scope notes</label>
            <textarea
              value={data.scopeNotes}
              onChange={(e) => update({ scopeNotes: clampText(e.target.value) })}
              rows={4}
              placeholder="In scope systems, locations, regulated constraints, or known dependencies."
              className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-slate-600 focus:border-[#6FA3C8]/50 focus:outline-none focus:ring-4 focus:ring-[#6FA3C8]/20"
            />
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="mt-8 space-y-6">
          <div>
            <label className="text-sm font-medium text-slate-300">Organization context</label>
            <input
              value={data.orgType}
              onChange={(e) => update({ orgType: clampText(e.target.value, 220) })}
              placeholder="Example: mid market SaaS, public sector adjacent, healthcare vendor."
              className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-slate-600 focus:border-[#6FA3C8]/50 focus:outline-none focus:ring-4 focus:ring-[#6FA3C8]/20"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-slate-300">Current state</label>
            <textarea
              value={data.currentState}
              onChange={(e) => update({ currentState: clampText(e.target.value) })}
              rows={5}
              placeholder="What is already in place. Policies, risk process, internal audit, evidence discipline, known gaps."
              className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-slate-600 focus:border-[#6FA3C8]/50 focus:outline-none focus:ring-4 focus:ring-[#6FA3C8]/20"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-slate-300">Constraints</label>
            <textarea
              value={data.constraints}
              onChange={(e) => update({ constraints: clampText(e.target.value) })}
              rows={4}
              placeholder="Resourcing, tooling, timelines, stakeholder alignment, data residency, vendor dependencies."
              className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-slate-600 focus:border-[#6FA3C8]/50 focus:outline-none focus:ring-4 focus:ring-[#6FA3C8]/20"
            />
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="mt-8 space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <div>
              <label className="text-sm font-medium text-slate-300">Name</label>
              <input
                value={data.contactName}
                onChange={(e) => update({ contactName: clampText(e.target.value, 120) })}
                placeholder="Primary contact"
                className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-slate-600 focus:border-[#6FA3C8]/50 focus:outline-none focus:ring-4 focus:ring-[#6FA3C8]/20"
              />
            </div>

            <div>
              <label className="text-sm font-medium text-slate-300">Email</label>
              <input
                value={data.contactEmail}
                onChange={(e) => update({ contactEmail: clampText(e.target.value, 180) })}
                type="email"
                placeholder="you@company.com"
                className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-slate-600 focus:border-[#6FA3C8]/50 focus:outline-none focus:ring-4 focus:ring-[#6FA3C8]/20"
              />
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-slate-300">Company</label>
            <input
              value={data.company}
              onChange={(e) => update({ company: clampText(e.target.value, 180) })}
              placeholder="Company name"
              className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-slate-600 focus:border-[#6FA3C8]/50 focus:outline-none focus:ring-4 focus:ring-[#6FA3C8]/20"
            />
          </div>

          <label className="flex items-start gap-3">
            <input
              type="checkbox"
              checked={data.consent}
              onChange={(e) => update({ consent: e.target.checked })}
              className="mt-1 h-4 w-4 rounded border-white/20 bg-white/5 text-white focus:ring-4 focus:ring-[#6FA3C8]/20"
            />
            <span className="text-sm leading-relaxed text-slate-400">
              I consent to being contacted regarding this readiness intake submission. We do not share information with third parties.
            </span>
          </label>

          <div className="rounded-xl border border-white/10 bg-white/[0.02] p-6">
            <div className="text-sm font-semibold text-white">Readiness summary</div>
            <div className="mt-4 grid gap-2 text-sm text-slate-400">
              {summary.lines.map(x => (
                <div key={x.k} className="flex gap-3">
                  <div className="w-40 flex-shrink-0 text-slate-500">{x.k}</div>
                  <div className="text-slate-300">{x.v}</div>
                </div>
              ))}
            </div>

            <div className="mt-6">
              <div className="text-xs font-medium tracking-widest text-[#6FA3C8] uppercase">Recommended pathway</div>
              <div className="mt-2 text-sm leading-relaxed text-slate-300">{summary.recommendedPathway}</div>
            </div>

            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              <button
                type="button"
                onClick={copySummary}
                className="inline-flex items-center justify-center rounded-full border border-white/15 px-5 py-2.5 text-sm font-semibold text-white transition-all hover:bg-white/5 focus:outline-none focus:ring-4 focus:ring-[#6FA3C8]/30"
              >
                Copy summary
              </button>

              <a
                href="mailto:hello@ascio.ca?subject=Readiness%20intake%20submission"
                className="inline-flex items-center justify-center rounded-full bg-white px-5 py-2.5 text-sm font-semibold text-slate-900 transition-all hover:bg-slate-100 focus:outline-none focus:ring-4 focus:ring-white/50"
              >
                Request advisory support
              </a>

              <a
                href="#"
                className="inline-flex items-center justify-center rounded-full border border-white/15 px-5 py-2.5 text-sm font-semibold text-white transition-all hover:bg-white/5 focus:outline-none focus:ring-4 focus:ring-[#6FA3C8]/30"
              >
                Schedule advisory session
              </a>
            </div>
          </div>
        </div>
      )}

      <div className="mt-10 flex items-center justify-between">
        <button
          type="button"
          onClick={() => setStep(s => Math.max(1, s - 1))}
          className={`rounded-full border border-white/15 px-5 py-2.5 text-sm font-semibold text-white transition-all hover:bg-white/5 focus:outline-none focus:ring-4 focus:ring-[#6FA3C8]/30 ${step === 1 ? "opacity-40 pointer-events-none" : ""}`}
        >
          Back
        </button>

        <button
          type="button"
          onClick={() => setStep(s => Math.min(3, s + 1))}
          disabled={!canNext}
          className={`rounded-full bg-white px-5 py-2.5 text-sm font-semibold text-slate-900 transition-all hover:bg-slate-100 focus:outline-none focus:ring-4 focus:ring-white/50 ${!canNext ? "opacity-40 pointer-events-none" : ""}`}
        >
          Continue
        </button>
      </div>
    </div>
  );
}
