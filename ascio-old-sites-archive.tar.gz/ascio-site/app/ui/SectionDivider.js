// app/ui/SectionDivider.js

export default function SectionDivider() {
  return <div className="mx-auto h-px max-w-7xl bg-gradient-to-r from-transparent via-[#6FA3C8]/20 to-transparent" />;
}
