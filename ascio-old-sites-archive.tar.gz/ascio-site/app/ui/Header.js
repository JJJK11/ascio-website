// app/ui/Header.js
"use client";

import { useEffect, useState } from "react";

const NAV = [
  { id: "services", label: "Services" },
  { id: "standards", label: "Standards" },
  { id: "approach", label: "Approach" },
  { id: "outcomes", label: "Outcomes" },
  { id: "about", label: "About" },
  { id: "intake", label: "Readiness intake" },
];

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("");

  useEffect(() => {
    const handleScroll = () => {
      const sections = NAV.map(x => x.id);
      const current = sections.find(id => {
        const el = document.getElementById(id);
        if (!el) return false;
        const rect = el.getBoundingClientRect();
        return rect.top <= 120 && rect.bottom >= 120;
      });
      setActiveSection(current || "");
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === "Escape") setMobileMenuOpen(false);
    };
    if (!mobileMenuOpen) return;
    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, [mobileMenuOpen]);

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-slate-950/95 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-8">
        <a
          href="/"
          className="flex items-center gap-3 rounded-lg focus:outline-none focus:ring-4 focus:ring-[#6FA3C8]/50 focus:ring-offset-2 focus:ring-offset-slate-950"
          aria-label="ascio advisory services - Home"
        >
          <img src="/ascio_Logo.png" alt="" className="h-9 w-auto" />
        </a>

        <nav className="hidden items-center gap-8 text-sm md:flex" aria-label="Main navigation">
          {NAV.map(({ id, label }) => (
            <a
              key={id}
              href={`#${id}`}
              className={`relative rounded px-2 py-1 text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-[#6FA3C8]/50 ${
                activeSection === id
                  ? "text-white after:absolute after:bottom-0 after:left-1/2 after:h-0.5 after:w-4 after:-translate-x-1/2 after:rounded-full after:bg-[#6FA3C8]"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              {label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href="#services"
            className="hidden rounded px-2 py-1 text-sm font-medium text-slate-400 transition-colors hover:text-white focus:outline-none focus:ring-2 focus:ring-[#6FA3C8]/50 md:inline"
          >
            View services
          </a>
          <a
            href="#intake"
            className="group relative overflow-hidden rounded-full bg-white px-5 py-2.5 text-sm font-semibold text-slate-900 transition-all hover:bg-slate-100 focus:outline-none focus:ring-4 focus:ring-white/50 focus:ring-offset-2 focus:ring-offset-slate-950"
          >
            Begin readiness intake
          </a>

          <button
            onClick={() => setMobileMenuOpen(v => !v)}
            className="md:hidden rounded-lg p-2 text-slate-400 hover:bg-white/10 focus:outline-none focus:ring-2 focus:ring-[#6FA3C8]/50"
            aria-label="Toggle menu"
            aria-expanded={mobileMenuOpen}
          >
            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              {mobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {mobileMenuOpen && (
        <>
          <div className="fixed inset-0 bg-black/40 md:hidden" onClick={() => setMobileMenuOpen(false)} aria-hidden="true" />
          <div className="relative border-t border-white/10 bg-slate-950 px-6 py-4 md:hidden">
            <nav className="flex flex-col gap-3 text-sm" aria-label="Mobile navigation">
              {NAV.map(({ id, label }) => (
                <a
                  key={id}
                  className="rounded py-2 text-slate-400 transition-colors hover:text-white focus:outline-none focus:ring-2 focus:ring-[#6FA3C8]/50"
                  href={`#${id}`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {label}
                </a>
              ))}
            </nav>
          </div>
        </>
      )}
    </header>
  );
}
