// app/ui/Standards.js

export default function Standards() {
  const primaryStandards = [
    { code: "ISO/IEC 27001", name: "Information security management" },
    { code: "ISO/IEC 42001", name: "AI management systems" },
    { code: "ISO/IEC 20000-1", name: "IT service management" },
    { code: "ISO 22301", name: "Business continuity management" },
    { code: "CyberSecure Canada", name: "SME-focused cyber hygiene" },
    { code: "CP-CSC", name: "Canadian cyber security", status: "Future program" }
  ];

  const additionalStandards = [
    { code: "ISO 9001", name: "Quality management" },
    { code: "ISO 14001", name: "Environmental management" },
    { code: "ISO 45001", name: "Occupational health and safety" },
    { code: "ISO 50001", name: "Energy management" }
  ];

  return (
    <section id="standards" className="bg-slate-900 py-24 md:py-32 scroll-mt-20">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mb-16">
          <div className="mb-4 text-xs font-medium tracking-widest text-[#6FA3C8] uppercase">
            Standards Scope
          </div>
          <h2 className="text-3xl font-bold tracking-tight text-white md:text-4xl">
            Technology management system standards
          </h2>
          <p className="mt-4 text-lg text-slate-400">
            Readiness support for management system standards commonly used in Canada.
          </p>
        </div>

        <div className="mb-8">
          <div className="text-sm font-medium text-slate-500 mb-4 uppercase tracking-wide">Primary focus</div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {primaryStandards.map((standard, idx) => (
              <div
                key={idx}
                className={`border ${standard.status ? 'border-white/5' : 'border-white/10'} ${standard.status ? 'bg-white/[0.02]' : 'bg-white/5'} p-6 rounded-xl ${!standard.status && 'hover:border-[#6FA3C8]/30 hover:bg-white/8'} transition-all`}
              >
                <div className={`mb-3 font-mono text-xs uppercase tracking-wide ${standard.status ? 'text-slate-600' : 'text-[#6FA3C8]'}`}>
                  {standard.code}
                  {standard.status && <span className="ml-2 text-slate-700">• {standard.status}</span>}
                </div>
                <div className={`text-sm font-medium leading-snug ${standard.status ? 'text-slate-500' : 'text-white'}`}>{standard.name}</div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="text-sm font-medium text-slate-500 mb-4 uppercase tracking-wide">Available on request</div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {additionalStandards.map((standard, idx) => (
              <div
                key={idx}
                className="border border-white/5 bg-white/[0.02] p-6 rounded-xl"
              >
                <div className="mb-3 font-mono text-xs uppercase tracking-wide text-slate-600">{standard.code}</div>
                <div className="text-sm font-medium leading-snug text-slate-500">{standard.name}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
