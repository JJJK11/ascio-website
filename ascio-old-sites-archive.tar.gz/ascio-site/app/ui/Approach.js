// app/ui/Approach.js

export default function Approach() {
  const phases = [
    {
      number: "01",
      phase: "Diagnose",
      description: "Current state assessment and gap identification",
      outputs: ["Gap assessment report", "Compliance maturity scoring", "Priority finding matrix"]
    },
    {
      number: "02",
      phase: "Design",
      description: "Control framework and documentation architecture",
      outputs: ["Risk register and control mapping", "Management system documentation pack", "Policy and procedure templates"]
    },
    {
      number: "03",
      phase: "Implement",
      description: "Deployment support and capability building",
      outputs: ["Implementation roadmap", "Training and awareness materials", "Evidence collection guidance"]
    },
    {
      number: "04",
      phase: "Validate",
      description: "Readiness verification and audit preparation",
      outputs: ["Internal audit plan and checklist", "Evidence matrix and readiness dashboard", "Corrective action tracking"]
    }
  ];

  return (
    <section id="approach" className="bg-slate-950 py-24 md:py-32 scroll-mt-20">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mb-16">
          <div className="mb-4 text-xs font-medium tracking-widest text-[#6FA3C8] uppercase">
            Methodology
          </div>
          <h2 className="text-3xl font-bold tracking-tight text-white md:text-4xl">
            Four-phase readiness approach
          </h2>
          <p className="mt-4 text-lg text-slate-400">
            Structured progression with clear deliverables at each stage.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {phases.map((phase, idx) => (
            <div key={idx} className="relative">
              <div className="mb-6">
                <div className="mb-3 font-mono text-xs uppercase tracking-widest text-slate-600">{phase.number}</div>
                <h3 className="mb-3 text-2xl font-semibold text-white">{phase.phase}</h3>
                <p className="text-sm leading-relaxed text-slate-500">{phase.description}</p>
              </div>
              <ul className="space-y-3">
                {phase.outputs.map((output, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-slate-500">
                    <div className="mt-1.5 h-1 w-1 flex-shrink-0 rounded-full bg-slate-600" />
                    <span>{output}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
