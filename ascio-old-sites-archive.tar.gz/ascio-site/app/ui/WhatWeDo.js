// app/ui/WhatWeDo.js

export default function WhatWeDo() {
  return (
    <section className="relative bg-slate-950 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-3xl">
          <div className="mb-4 text-xs font-medium tracking-widest text-[#6FA3C8] uppercase">
            Independent Advisory
          </div>
          <h2 className="text-3xl font-bold tracking-tight text-white md:text-4xl mb-6">
            Technology management system readiness
          </h2>
          <p className="text-lg leading-relaxed text-slate-400">
            We provide readiness and implementation support. We do not issue certifications and we do not provide audit opinions. 
            Our work focuses on governance, controls, and evidence so teams can operate with clarity and discipline.
          </p>
        </div>
      </div>
    </section>
  );
}
