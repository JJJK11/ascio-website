// app/ui/Hero.js

export default function Hero() {
  return (
    <section id="main-content" className="relative overflow-hidden bg-gradient-to-b from-slate-900 to-slate-950 scroll-mt-20">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff08_1px,transparent_1px),linear-gradient(to_bottom,#ffffff08_1px,transparent_1px)] bg-[size:32px_32px]" />
      <div className="absolute left-0 top-0 h-[600px] w-[600px] -translate-x-1/3 -translate-y-1/3 rounded-full bg-[#6FA3C8]/5 blur-3xl" />
      <div className="absolute right-0 top-20 h-[500px] w-[500px] translate-x-1/3 rounded-full bg-[#6FA3C8]/3 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-6 pb-24 pt-24 md:pb-32 md:pt-32 lg:px-8">
        <div className="grid gap-16 md:grid-cols-12">
          <div className="md:col-span-7">
            <div className="mb-8">
              <img src="/ascio_Icon.png" alt="ascio" className="h-16 w-auto md:h-20" />
            </div>

            <div className="mt-4 text-sm font-medium tracking-wide text-slate-500 uppercase">
              Technology management systems
            </div>

            <h1 className="mt-8 text-4xl font-bold leading-[1.1] tracking-tight text-white md:text-5xl lg:text-6xl">
              Control design.<br />
              Evidence architecture.<br />
              Readiness execution.
            </h1>

            <p className="mt-8 max-w-2xl text-lg leading-relaxed text-slate-400 md:text-xl">
              We provide advisory support for ISO IEC 27001, ISO IEC 42001, ISO IEC 20000-1, and ISO 22301.
              Our work focuses on governance, controls, and evidence so teams can operate with clarity and discipline.
            </p>

            <div className="mt-12 flex flex-col gap-4 sm:flex-row">
              <a
                href="#intake"
                className="inline-flex items-center justify-center rounded-full bg-white px-6 py-3 text-sm font-semibold text-slate-900 transition-all hover:bg-slate-100 focus:outline-none focus:ring-4 focus:ring-white/50 focus:ring-offset-2 focus:ring-offset-slate-950"
              >
                Begin readiness intake
                <svg className="ml-2 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </a>

              <a
                href="#services"
                className="inline-flex items-center justify-center rounded-full border border-white/20 px-6 py-3 text-sm font-semibold text-white transition-all hover:border-white/40 hover:bg-white/5 focus:outline-none focus:ring-4 focus:ring-[#6FA3C8]/50 focus:ring-offset-2 focus:ring-offset-slate-950"
              >
                View services
              </a>
            </div>
          </div>

          <div className="md:col-span-5 flex items-center">
            <div className="grid grid-cols-2 gap-x-12 gap-y-8 text-sm">
              <div>
                <div className="mb-1 font-semibold text-white">Standards aligned</div>
                <div className="text-slate-500">Requirements interpreted with precision</div>
              </div>
              <div>
                <div className="mb-1 font-semibold text-white">Evidence first</div>
                <div className="text-slate-500">Traceability across controls and records</div>
              </div>
              <div>
                <div className="mb-1 font-semibold text-white">Governance ready</div>
                <div className="text-slate-500">Ownership, cadence, and escalation paths</div>
              </div>
              <div>
                <div className="mb-1 font-semibold text-white">Canadian delivery</div>
                <div className="text-slate-500">Designed for regulated environments</div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-14 text-xs text-slate-600">
          Guidance is informational only and does not constitute certification, assessment, legal advice, or audit opinion.
        </div>
      </div>
    </section>
  );
}
