// app/ui/Footer.js

export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-slate-950">
      <div className="mx-auto max-w-7xl px-6 py-16 lg:px-8">
        <div className="grid gap-12 md:grid-cols-12">
          <div className="md:col-span-4">
            <img 
              src="/ascio_Logo.png" 
              alt="ascio" 
              className="h-9 w-auto"
            />
            <div className="mt-4 text-sm font-medium text-white">
              Technology Management Systems
            </div>
            <div className="mt-2 text-sm text-slate-500">
              Independent Advisory
            </div>
            <div className="mt-6 text-xs text-slate-600">
              © {new Date().getFullYear()} ascio advisory services
            </div>
            <div className="mt-2 text-xs text-slate-600">
              Independent from certification bodies
            </div>
            <div className="mt-4 text-xs text-slate-600 leading-relaxed">
              Guidance is informational only and does not constitute certification, assessment, legal advice, or audit opinion.
            </div>
          </div>

          <div className="md:col-span-8 md:flex md:justify-end">
            <div className="grid gap-8 sm:grid-cols-3">
              <div>
                <div className="text-sm font-semibold text-white mb-3">Services</div>
                <div className="space-y-2 text-sm text-slate-500">
                  <a className="block transition-colors hover:text-white focus:outline-none focus:ring-2 focus:ring-[#6FA3C8]/50 rounded" href="#services">Advisory services</a>
                  <a className="block transition-colors hover:text-white focus:outline-none focus:ring-2 focus:ring-[#6FA3C8]/50 rounded" href="#standards">Standards</a>
                  <a className="block transition-colors hover:text-white focus:outline-none focus:ring-2 focus:ring-[#6FA3C8]/50 rounded" href="#approach">Approach</a>
                </div>
              </div>
              
              <div>
                <div className="text-sm font-semibold text-white mb-3">Company</div>
                <div className="space-y-2 text-sm text-slate-500">
                  <a className="block transition-colors hover:text-white focus:outline-none focus:ring-2 focus:ring-[#6FA3C8]/50 rounded" href="#about">About</a>
                  <a className="block transition-colors hover:text-white focus:outline-none focus:ring-2 focus:ring-[#6FA3C8]/50 rounded" href="#outcomes">Outcomes</a>
                  <a className="block transition-colors hover:text-white focus:outline-none focus:ring-2 focus:ring-[#6FA3C8]/50 rounded" href="#intake">Readiness intake</a>
                </div>
              </div>
              
              <div>
                <div className="text-sm font-semibold text-white mb-3">Contact</div>
                <div className="space-y-2 text-sm text-slate-500">
                  <a className="block transition-colors hover:text-[#6FA3C8]" href="mailto:hello@ascio.ca">hello@ascio.ca</a>
                  <div>Canada</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
