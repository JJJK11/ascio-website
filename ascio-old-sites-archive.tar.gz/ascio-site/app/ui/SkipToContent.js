// app/ui/SkipToContent.js

export default function SkipToContent() {
  return (
    <a
      href="#main-content"
      className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:text-slate-900 focus:outline-none focus:ring-4 focus:ring-white/50"
    >
      Skip to content
    </a>
  );
}
