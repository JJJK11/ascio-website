// app/ui/About.js

export default function About() {
  return (
    <section id="about" className="bg-slate-950 py-24 md:py-32 scroll-mt-20">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid gap-16 md:grid-cols-2">
          <div>
            <div className="mb-4 text-xs font-medium tracking-widest text-[#6FA3C8] uppercase">
              About ascio
            </div>
            <h2 className="mb-10 text-3xl font-bold tracking-tight text-white md:text-4xl">
              Technology governance for readiness success
            </h2>
            <div className="space-y-6 leading-relaxed text-slate-400">
              <p>
                We believe readiness is a technical discipline requiring structured methodology, evidence rigor, and control precision.
              </p>
              <p>
                ascio works with mid-market organizations, public sector adjacent entities, regulated industries, and technology-enabled companies seeking standards-based governance frameworks and readiness success.
              </p>
              <p>
                We deliver Canada-first advisory services with a focus on audit preparedness, documentation quality, and sustainable implementation.
              </p>
            </div>
          </div>

          <div className="bg-gradient-to-b from-white/4 to-transparent p-10 rounded-xl">
            <h3 className="mb-8 text-xl font-semibold text-white">Our approach</h3>
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="mt-2 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-[#6FA3C8]" />
                <div>
                  <div className="mb-2 font-semibold text-white">Evidence-driven</div>
                  <div className="leading-relaxed text-slate-400">Documentation and controls designed for audit scrutiny</div>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="mt-2 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-[#6FA3C8]" />
                <div>
                  <div className="mb-2 font-semibold text-white">Standards-aligned</div>
                  <div className="leading-relaxed text-slate-400">Requirements interpretation and mapping to organizational context</div>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="mt-2 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-[#6FA3C8]" />
                <div>
                  <div className="mb-2 font-semibold text-white">Outcome-focused</div>
                  <div className="leading-relaxed text-slate-400">Readiness verification through structured validation</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
