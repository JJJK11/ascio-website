// app/ui/Outcomes.js

export default function Outcomes() {
  return (
    <section id="outcomes" className="bg-slate-900 py-24 md:py-32 scroll-mt-20">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mb-16">
          <div className="mb-4 text-xs font-medium tracking-widest text-[#6FA3C8] uppercase">
            Client Outcomes
          </div>
          <h2 className="text-3xl font-bold tracking-tight text-white md:text-4xl">
            Measurable readiness improvements
          </h2>
        </div>

        <div className="grid gap-8 md:grid-cols-3 mb-16">
          <div>
            <h3 className="text-xl font-semibold text-white mb-3">Reduced audit rework</h3>
            <p className="text-slate-400 leading-relaxed">Through evidence planning and documentation rigor</p>
          </div>
          <div>
            <h3 className="text-xl font-semibold text-white mb-3">Faster readiness cycles</h3>
            <p className="text-slate-400 leading-relaxed">Through structured implementation and clear deliverables</p>
          </div>
          <div>
            <h3 className="text-xl font-semibold text-white mb-3">Stronger governance</h3>
            <p className="text-slate-400 leading-relaxed">Through defined controls and accountability frameworks</p>
          </div>
        </div>

        <div className="bg-gradient-to-b from-white/4 to-transparent p-10 rounded-xl">
          <h3 className="mb-8 text-2xl font-semibold text-white">What clients receive</h3>
          <div className="grid gap-x-16 gap-y-5 md:grid-cols-2">
            {[
              "Comprehensive gap assessment and readiness scoring",
              "Management system documentation aligned with standards",
              "Risk registers and control effectiveness mapping",
              "Internal audit plans, checklists, and training",
              "Evidence matrices and compliance dashboards",
              "Corrective action plans with verification support",
              "Implementation guidance and stakeholder engagement",
              "Regular progress reviews and adjustment cycles"
            ].map((item, idx) => (
              <div key={idx} className="flex items-start gap-4">
                <div className="mt-1.5 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-[#6FA3C8]" />
                <span className="leading-relaxed text-slate-400">{item}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
