// app/ui/Programs.js

export default function Programs() {
  const services = [
    {
      title: "Readiness baseline and action plan",
      description: "Comprehensive gap analysis against standard requirements with prioritized action planning.",
      features: ["Gap identification and evidence mapping", "Readiness scoring and risk assessment", "Detailed finding documentation"]
    },
    {
      title: "Management system design",
      description: "Structured documentation and control frameworks tailored to organizational context.",
      features: ["Policy and procedure development", "Process mapping and integration", "Control design and assignment"]
    },
    {
      title: "Internal audit program setup",
      description: "Audit planning, execution support, and capability building for internal teams.",
      features: ["Audit checklist templates", "Finding classification guide", "Auditor training materials"]
    },
    {
      title: "Corrective action planning",
      description: "Root cause analysis and remediation strategies for identified nonconformities.",
      features: ["Finding analysis and classification", "Corrective action plan design", "Verification and closure support"]
    },
    {
      title: "Risk management framework",
      description: "Risk identification, assessment methodology, and control mapping to standard requirements.",
      features: ["Risk register development", "Control effectiveness assessment", "Treatment plan documentation"]
    },
    {
      title: "Documentation framework",
      description: "Policy, procedure, and records architecture aligned with standard requirements.",
      features: ["Document hierarchy design", "Template creation and guidance", "Version control and approval workflow"]
    },
    {
      title: "CyberSecure Canada readiness support",
      description: "SME-focused cyber hygiene readiness support and baseline control implementation.",
      features: ["Baseline control assessment", "Evidence mapping and control traceability", "Lightweight documentation support"]
    },
    {
      title: "CP-CSC advisory support",
      description: "Defence sector cyber security readiness planning (future program - pending regulatory approval).",
      features: ["Program rule monitoring", "Defence requirements alignment", "Readiness planning support"],
      status: "Future program"
    }
  ];

  return (
    <section id="services" className="bg-slate-950 py-24 md:py-32 scroll-mt-20">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mb-16">
          <div className="mb-4 text-xs font-medium tracking-widest text-[#6FA3C8] uppercase">
            Advisory Services
          </div>
          <h2 className="text-3xl font-bold tracking-tight text-white md:text-4xl">
            Technology management system advisory
          </h2>
          <p className="mt-4 text-lg text-slate-400">
            Control design, evidence architecture, and audit readiness.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {services.map((service, idx) => (
            <div
              key={idx}
              className={`${service.status ? 'bg-gradient-to-b from-white/[0.02] to-transparent opacity-60' : 'bg-gradient-to-b from-white/4 to-transparent'} p-8 rounded-xl ${!service.status && 'hover:from-white/6'} transition-all`}
            >
              <h3 className="text-lg font-semibold text-white mb-3">
                {service.title}
                {service.status && <span className="ml-2 text-xs text-slate-600 font-normal">({service.status})</span>}
              </h3>
              <p className="text-sm leading-relaxed text-slate-500 mb-6">{service.description}</p>
              <ul className="space-y-3">
                {service.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-slate-400">
                    <div className="mt-1.5 h-1 w-1 rounded-full bg-[#6FA3C8] flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
