# Setup ascio Website with Claude Code

## Quick Start Instructions

### FIRST: Navigate to Your Project Folder

In Claude Code terminal, run:
```bash
cd C:\Users\kalke\Documents\Projects\ASCIO-Website
```

---

## Copy/Paste This Exact Prompt to Claude Code:

```
I'm in C:\Users\kalke\Documents\Projects\ASCIO-Website

Set up a Next.js site for me here:

1. Run: npx create-next-app@latest ascio-site
   When prompted, select:
   - TypeScript? NO
   - ESLint? YES
   - Tailwind CSS? YES
   - src/ directory? NO
   - App Router? YES
   - Custom import alias? NO

2. cd ascio-site

3. Run: npm install lucide-react

4. I have ascio_Logo.png, ascio_Icon.png, and ascio_Favicon.png files. Copy them to the public/ folder.

5. I have an ascio-website.jsx file with the website code. Replace app/page.js with its content, but change all image paths from '/mnt/user-data/uploads/ascio_Logo.png' to '/ascio_Logo.png'

6. Run: npm run dev

7. Tell me the localhost URL to visit
```

---

## Alternative: Step-by-Step Method

If you prefer to do it step by step, paste each command one at a time:

**Step 1: Navigate**
```
cd C:\Users\kalke\Documents\Projects\ASCIO-Website
```

**Step 2: Create Next.js Project**
```
npx create-next-app@latest ascio-site
```
Then select: No TypeScript, Yes ESLint, Yes Tailwind, No src/, Yes App Router, No custom alias

**Step 3: Enter Project**
```
cd ascio-site
```

**Step 4: Install Dependencies**
```
npm install lucide-react
```

**Step 5: Copy Logo Files**
```
Copy the three logo files (ascio_Logo.png, ascio_Icon.png, ascio_Favicon.png) to the public/ folder
```

**Step 6: Update Website Code**
```
Replace app/page.js with the content from ascio-website.jsx, changing image paths from '/mnt/user-data/uploads/ascio_Logo.png' to '/ascio_Logo.png'
```

**Step 7: Start Server**
```
npm run dev
```

**Step 8: Open Browser**
```
http://localhost:3000
```

---

## What You'll See

Claude Code will:
- Execute all the commands
- Set up the project structure
- Install dependencies
- Configure files
- Start the server
- Give you the localhost URL to visit

---

## After Setup

Once it's running, you can ask Claude Code to:
- "Make the hero headline larger"
- "Change the accent color to blue"
- "Add a new service card"
- "Update the contact email"

Claude Code will edit the files and the changes will hot-reload automatically!

---

## Key Point

The main file to edit is: **app/page.js**

Everything is in this one React component, making it easy to modify.
