'use client';

import React, { useState, useEffect } from 'react';
import { ChevronRight, Check } from 'lucide-react';

export default function Home() {
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('');
  const [formData, setFormData] = useState({
    name: '', email: '', company: '', standard: '', timeline: '', notes: ''
  });

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);

      const sections = ['services', 'standards', 'approach', 'outcomes', 'about', 'contact'];
      const current = sections.find(section => {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          return rect.top <= 100 && rect.bottom >= 100;
        }
        return false;
      });
      if (current) setActiveSection(current);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    alert('Thank you for your interest. We will contact you within 24 hours.');
  };

  return (
    <div className="font-sans antialiased bg-gray-900 text-white">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Work+Sans:wght@300;400;500;600;700&display=swap');

        * { margin: 0; padding: 0; box-sizing: border-box; }

        .font-serif { font-family: 'Instrument Serif', serif; }
        .font-sans { font-family: 'Work Sans', sans-serif; }

        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(32px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .animate-fade-up {
          animation: fadeUp 0.7s ease-out forwards;
          opacity: 0;
        }

        .delay-100 { animation-delay: 0.1s; }
        .delay-200 { animation-delay: 0.2s; }
        .delay-300 { animation-delay: 0.3s; }
        .delay-400 { animation-delay: 0.4s; }

        .line-separator {
          height: 1px;
          background: linear-gradient(to right, transparent, rgba(255,255,255,0.1) 20%, rgba(255,255,255,0.1) 80%, transparent);
        }

        .accent-link {
          color: rgba(255, 255, 255, 0.7);
          transition: color 0.2s ease;
        }

        .accent-link:hover {
          color: #ffffff;
        }

        .card-hover {
          transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .card-hover:hover {
          transform: translateY(-2px);
          border-color: rgba(255, 255, 255, 0.2);
          box-shadow: 0 12px 32px rgba(0, 0, 0, 0.4);
        }

        input, textarea, select {
          font-family: 'Work Sans', sans-serif;
        }

        input::placeholder, textarea::placeholder {
          color: rgba(255, 255, 255, 0.4);
        }

        html {
          scroll-behavior: smooth;
        }
      `}</style>

      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-black/90 backdrop-blur-xl shadow-2xl py-4' : 'bg-transparent py-6'
      }`}>
        <div className="max-w-7xl mx-auto px-8 flex items-center justify-between">
          <div className="flex items-center">
            <img src="/ascio_Logo.png" alt="ascio" className="h-9 w-auto brightness-0 invert" />
          </div>

          <nav className="hidden md:flex items-center gap-10 text-sm font-medium">
            {['services', 'standards', 'approach', 'outcomes', 'about', 'contact'].map((section) => (
              <a
                key={section}
                href={`#${section}`}
                className={`accent-link ${activeSection === section ? 'text-white' : ''}`}
              >
                {section.charAt(0).toUpperCase() + section.slice(1)}
              </a>
            ))}
          </nav>

          <button className="bg-white text-gray-900 px-6 py-2.5 rounded-lg text-sm font-semibold hover:bg-gray-100 transition-all shadow-lg">
            Book a readiness call
          </button>
        </div>
      </header>

      <section className="pt-48 pb-32 px-8">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-5xl">
            <div className="animate-fade-up mb-12">
              <h1 className="font-serif text-7xl md:text-8xl font-normal tracking-tight leading-tight mb-8 text-white">
                Certification readiness.<br />
                Standards-led delivery.
              </h1>
            </div>

            <div className="animate-fade-up delay-100 mb-12">
              <p className="text-xl text-white/70 mb-0 max-w-3xl leading-relaxed font-light">
                ascio provides management system advisory and certification readiness support to help
                organizations achieve successful certification outcomes.
              </p>
            </div>

            <div className="animate-fade-up delay-200 flex flex-wrap gap-4 mb-14">
              <span className="px-5 py-2.5 bg-white/10 text-white text-sm font-medium rounded-full border border-white/20 backdrop-blur-sm hover:bg-white/15 transition-all">
                Standards-led
              </span>
              <span className="px-5 py-2.5 bg-white/10 text-white text-sm font-medium rounded-full border border-white/20 backdrop-blur-sm hover:bg-white/15 transition-all">
                Audit-ready
              </span>
              <span className="px-5 py-2.5 bg-white/10 text-white text-sm font-medium rounded-full border border-white/20 backdrop-blur-sm hover:bg-white/15 transition-all">
                Evidence-based
              </span>
              <span className="px-5 py-2.5 bg-white/10 text-white text-sm font-medium rounded-full border border-white/20 backdrop-blur-sm hover:bg-white/15 transition-all">
                Canadian delivery
              </span>
            </div>

            <div className="animate-fade-up delay-300 flex gap-4">
              <button className="bg-white text-gray-900 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-all flex items-center gap-2 shadow-lg">
                Book a readiness call
                <ChevronRight size={20} strokeWidth={2.5} />
              </button>
              <button className="bg-transparent text-white px-8 py-4 rounded-lg font-semibold border-2 border-white/30 hover:border-white/50 hover:bg-white/5 transition-all">
                View services
              </button>
            </div>
          </div>
        </div>
      </section>

      <div className="line-separator max-w-7xl mx-auto my-20" />

      <section id="services" className="py-32 px-8">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl mb-20">
            <h2 className="font-serif text-5xl font-normal mb-6 tracking-tight text-white leading-tight">Advisory services</h2>
            <p className="text-lg text-white/60 font-light leading-relaxed">
              Structured support for certification readiness across all phases of management system implementation.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Certification readiness assessment",
                desc: "Comprehensive gap analysis against standard requirements with prioritized action planning.",
                items: ["Gap identification and evidence mapping", "Readiness scoring and risk assessment", "Detailed finding documentation"]
              },
              {
                title: "Management system design",
                desc: "Structured documentation and control frameworks tailored to organizational context.",
                items: ["Policy and procedure development", "Process mapping and integration", "Control design and assignment"]
              },
              {
                title: "Internal audit program setup",
                desc: "Audit planning, execution support, and capability building for internal teams.",
                items: ["Audit plan development", "Checklist and tool creation", "Auditor coaching and training"]
              },
              {
                title: "Corrective action planning",
                desc: "Root cause analysis and remediation strategies for identified nonconformities.",
                items: ["Finding analysis and classification", "Corrective action plan design", "Verification and closure support"]
              },
              {
                title: "Risk management framework",
                desc: "Risk identification, assessment methodology, and control mapping to standard requirements.",
                items: ["Risk register development", "Control effectiveness assessment", "Treatment plan documentation"]
              },
              {
                title: "Documentation framework",
                desc: "Policy, procedure, and records architecture aligned with standard requirements.",
                items: ["Document hierarchy design", "Template creation and guidance", "Version control and approval workflow"]
              },
              {
                title: "Implementation support",
                desc: "Training, coaching, and change management for successful system adoption.",
                items: ["Awareness and training delivery", "Implementation roadmap", "Stakeholder engagement planning"]
              }
            ].map((service, idx) => (
              <div key={idx} className="p-8 bg-white/5 border border-white/10 rounded-2xl card-hover backdrop-blur-sm">
                <h3 className="font-semibold text-lg mb-3 text-white">{service.title}</h3>
                <p className="text-white/60 text-sm mb-6 font-light leading-relaxed">{service.desc}</p>
                <ul className="space-y-3">
                  {service.items.map((item, i) => (
                    <li key={i} className="text-sm text-white/70 flex items-start gap-3">
                      <Check size={16} className="mt-0.5 text-white/40 flex-shrink-0" strokeWidth={2.5} />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="line-separator max-w-7xl mx-auto my-20" />

      <section id="standards" className="py-32 px-8 bg-black/40">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl mb-20">
            <h2 className="font-serif text-5xl font-normal mb-6 tracking-tight text-white leading-tight">Standards scope</h2>
            <p className="text-lg text-white/60 font-light leading-relaxed">
              Advisory support across SCC management system programs.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { code: "ISO/IEC 27001", name: "Information security management" },
              { code: "ISO/IEC 42001", name: "AI management systems" },
              { code: "ISO 9001", name: "Quality management" },
              { code: "ISO 14001", name: "Environmental management" },
              { code: "ISO 45001", name: "Occupational health and safety" },
              { code: "ISO 22301", name: "Business continuity" },
              { code: "ISO/IEC 20000-1", name: "IT service management" },
              { code: "ISO 50001", name: "Energy management" }
            ].map((standard, idx) => (
              <div key={idx} className="p-7 bg-white/5 border border-white/10 rounded-xl backdrop-blur-sm hover:bg-white/8 transition-all">
                <div className="font-mono text-xs text-white/50 mb-3 tracking-wide uppercase">{standard.code}</div>
                <div className="text-sm font-medium text-white/90 leading-snug">{standard.name}</div>
              </div>
            ))}
            <div className="p-7 bg-white/5 border border-white/20 border-dashed rounded-xl flex items-center justify-center backdrop-blur-sm">
              <div className="text-sm text-white/60 text-center font-light">
                Other management system standards on request
              </div>
            </div>
          </div>

          <div className="mt-16 p-8 bg-white/5 border border-white/10 text-white rounded-xl max-w-4xl backdrop-blur-sm">
            <p className="text-base leading-relaxed font-light text-white/80">
              ascio supports organizations through every phase of their certification journey, from initial
              gap assessment to audit readiness, working alongside independent certification bodies to ensure
              successful outcomes.
            </p>
          </div>
        </div>
      </section>

      <div className="line-separator max-w-7xl mx-auto my-20" />

      <section id="approach" className="py-32 px-8">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl mb-20">
            <h2 className="font-serif text-5xl font-normal mb-6 tracking-tight text-white leading-tight">The ascio method</h2>
            <p className="text-lg text-white/60 font-light leading-relaxed">
              A structured four-phase approach to certification readiness with clear deliverables and outcomes.
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-12">
            {[
              {
                phase: "Diagnose",
                number: "01",
                desc: "Current state assessment and gap identification",
                outputs: ["Gap assessment report", "Compliance maturity scoring", "Priority finding matrix"]
              },
              {
                phase: "Design",
                number: "02",
                desc: "Control framework and documentation architecture",
                outputs: ["Risk register and control mapping", "Management system documentation pack", "Policy and procedure templates"]
              },
              {
                phase: "Implement",
                number: "03",
                desc: "Deployment support and capability building",
                outputs: ["Implementation roadmap", "Training and awareness materials", "Evidence collection guidance"]
              },
              {
                phase: "Validate",
                number: "04",
                desc: "Readiness verification and audit preparation",
                outputs: ["Internal audit plan and checklist", "Evidence matrix and readiness dashboard", "Corrective action tracking"]
              }
            ].map((phase, idx) => (
              <div key={idx} className="relative">
                <div className="mb-6">
                  <div className="font-mono text-xs text-white/40 mb-3 tracking-widest">{phase.number}</div>
                  <h3 className="text-2xl font-serif font-normal mb-3 text-white">{phase.phase}</h3>
                  <p className="text-sm text-white/60 font-light leading-relaxed">{phase.desc}</p>
                </div>
                <div className="space-y-3">
                  {phase.outputs.map((output, i) => (
                    <div key={i} className="text-sm text-white/70 flex items-start gap-3">
                      <div className="w-1.5 h-1.5 rounded-full bg-white/30 mt-2 flex-shrink-0" />
                      <span className="font-light">{output}</span>
                    </div>
                  ))}
                </div>
                {idx < 3 && (
                  <div className="hidden md:block absolute top-0 -right-6 w-12 h-px bg-white/10"
                       style={{ top: '3rem' }} />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="line-separator max-w-7xl mx-auto my-20" />

      <section id="outcomes" className="py-32 px-8 bg-black/40">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl mb-20">
            <h2 className="font-serif text-5xl font-normal mb-6 tracking-tight text-white leading-tight">Outcomes</h2>
            <p className="text-lg text-white/60 font-light leading-relaxed">
              Measurable improvements in readiness, governance, and audit performance.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-10 mb-20">
            {[
              { outcome: "Reduced audit rework", detail: "Through evidence planning and documentation rigor" },
              { outcome: "Faster readiness cycles", detail: "Through structured implementation and clear deliverables" },
              { outcome: "Stronger governance", detail: "Through defined controls and accountability frameworks" }
            ].map((item, idx) => (
              <div key={idx}>
                <h3 className="text-xl font-semibold mb-3 text-white">{item.outcome}</h3>
                <p className="text-white/60 font-light leading-relaxed">{item.detail}</p>
              </div>
            ))}
          </div>

          <div className="bg-white/5 border border-white/10 rounded-2xl p-10 backdrop-blur-sm">
            <h3 className="text-3xl font-serif font-normal mb-8 text-white">What clients receive</h3>
            <div className="grid md:grid-cols-2 gap-x-16 gap-y-5">
              {[
                "Comprehensive gap assessment and readiness scoring",
                "Management system documentation aligned with standards",
                "Risk registers and control effectiveness mapping",
                "Internal audit plans, checklists, and training",
                "Evidence matrices and compliance dashboards",
                "Corrective action plans with verification support",
                "Implementation guidance and stakeholder engagement",
                "Regular progress reviews and adjustment cycles"
              ].map((item, idx) => (
                <div key={idx} className="flex items-start gap-4">
                  <Check size={20} className="text-white/40 flex-shrink-0 mt-1" strokeWidth={2.5} />
                  <span className="text-white/80 font-light leading-relaxed">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <div className="line-separator max-w-7xl mx-auto my-20" />

      <section id="about" className="py-32 px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-20">
            <div>
              <h2 className="font-serif text-5xl font-normal mb-10 tracking-tight text-white leading-tight">About ascio</h2>
              <div className="space-y-6 text-white/70 font-light leading-relaxed">
                <p>
                  We believe certification readiness is a technical discipline requiring structured methodology,
                  evidence rigor, and control precision.
                </p>
                <p>
                  ascio works with mid-market organizations, public sector adjacent entities, regulated industries,
                  and technology-enabled companies seeking standards-based governance frameworks and certification success.
                </p>
                <p>
                  We deliver Canada-first advisory services with a focus on audit preparedness, documentation
                  quality, and sustainable implementation that leads to successful certification outcomes.
                </p>
              </div>
            </div>

            <div className="bg-white/5 border border-white/10 text-white rounded-2xl p-10 backdrop-blur-sm">
              <h3 className="text-xl font-semibold mb-8 text-white">Our approach</h3>
              <div className="space-y-6 text-sm font-light">
                <div className="flex gap-4">
                  <div className="w-2 h-2 rounded-full bg-white/40 mt-2 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-white mb-2">Evidence-driven</div>
                    <div className="text-white/70 leading-relaxed">Documentation and controls designed for audit scrutiny</div>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-2 h-2 rounded-full bg-white/40 mt-2 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-white mb-2">Standards-aligned</div>
                    <div className="text-white/70 leading-relaxed">Requirements interpretation and mapping to organizational context</div>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-2 h-2 rounded-full bg-white/40 mt-2 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-white mb-2">Outcome-focused</div>
                    <div className="text-white/70 leading-relaxed">Readiness verification through structured validation</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="line-separator max-w-7xl mx-auto my-20" />

      <section id="contact" className="py-32 px-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-16">
            <h2 className="font-serif text-5xl font-normal mb-6 tracking-tight text-white leading-tight">Request a readiness call</h2>
            <p className="text-lg text-white/60 font-light leading-relaxed">
              Discuss your certification objectives and readiness timeline.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <label className="block text-sm font-medium text-white/80 mb-3">Name</label>
                <input
                  type="text"
                  required
                  className="w-full px-5 py-4 bg-white/5 border border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-white/30 focus:border-transparent text-white placeholder-white/40 backdrop-blur-sm"
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-white/80 mb-3">Email</label>
                <input
                  type="email"
                  required
                  className="w-full px-5 py-4 bg-white/5 border border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-white/30 focus:border-transparent text-white placeholder-white/40 backdrop-blur-sm"
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-white/80 mb-3">Company</label>
              <input
                type="text"
                required
                className="w-full px-5 py-4 bg-white/5 border border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-white/30 focus:border-transparent text-white placeholder-white/40 backdrop-blur-sm"
                onChange={(e) => setFormData({...formData, company: e.target.value})}
              />
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <label className="block text-sm font-medium text-white/80 mb-3">Standard of interest</label>
                <select
                  required
                  className="w-full px-5 py-4 bg-white/5 border border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-white/30 focus:border-transparent text-white backdrop-blur-sm"
                  onChange={(e) => setFormData({...formData, standard: e.target.value})}
                >
                  <option value="" className="bg-gray-900">Select a standard</option>
                  <option className="bg-gray-900">ISO/IEC 27001</option>
                  <option className="bg-gray-900">ISO/IEC 42001</option>
                  <option className="bg-gray-900">ISO 9001</option>
                  <option className="bg-gray-900">ISO 14001</option>
                  <option className="bg-gray-900">ISO 45001</option>
                  <option className="bg-gray-900">ISO 22301</option>
                  <option className="bg-gray-900">ISO/IEC 20000-1</option>
                  <option className="bg-gray-900">ISO 50001</option>
                  <option className="bg-gray-900">Other</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-white/80 mb-3">Timeline</label>
                <select
                  required
                  className="w-full px-5 py-4 bg-white/5 border border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-white/30 focus:border-transparent text-white backdrop-blur-sm"
                  onChange={(e) => setFormData({...formData, timeline: e.target.value})}
                >
                  <option value="" className="bg-gray-900">Select timeline</option>
                  <option className="bg-gray-900">Within 3 months</option>
                  <option className="bg-gray-900">3-6 months</option>
                  <option className="bg-gray-900">6-12 months</option>
                  <option className="bg-gray-900">12+ months</option>
                  <option className="bg-gray-900">Exploratory</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-white/80 mb-3">Additional details</label>
              <textarea
                rows={4}
                className="w-full px-5 py-4 bg-white/5 border border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-white/30 focus:border-transparent resize-none text-white placeholder-white/40 backdrop-blur-sm"
                onChange={(e) => setFormData({...formData, notes: e.target.value})}
              />
            </div>

            <button
              type="submit"
              className="bg-white text-gray-900 px-10 py-4 rounded-xl font-semibold hover:bg-gray-100 transition-all flex items-center gap-2 shadow-lg"
            >
              Submit request
              <ChevronRight size={20} strokeWidth={2.5} />
            </button>
          </form>

          <div className="mt-16 pt-10 border-t border-white/10">
            <div className="grid md:grid-cols-2 gap-10">
              <div>
                <div className="font-semibold text-white mb-3">Email</div>
                <a href="mailto:hello@ascio.ca" className="accent-link">hello@ascio.ca</a>
              </div>
              <div>
                <div className="font-semibold text-white mb-3">Location</div>
                <div className="text-white/60 font-light">Canada</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/10 py-16 px-8 bg-black/40 mt-20">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8">
            <div className="flex items-center">
              <img src="/ascio_Logo.png" alt="ascio" className="h-8 w-auto brightness-0 invert opacity-60" />
            </div>

            <div className="flex gap-10 text-sm">
              <a href="#" className="accent-link">Privacy</a>
              <a href="#" className="accent-link">Terms</a>
              <a href="#contact" className="accent-link">Contact</a>
            </div>
          </div>

          <div className="mt-10 pt-10 border-t border-white/10">
            <p className="text-xs text-white/40 font-light max-w-3xl leading-relaxed">
              ascio advisory services supports organizations in achieving certification readiness through
              structured management system implementation and audit preparation.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
